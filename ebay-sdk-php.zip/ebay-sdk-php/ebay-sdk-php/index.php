<?php
ini_set('memory_limit', '8192');
require __DIR__.'/vendor/autoload.php';
require_once 'simple_html_dom.php';
use \DTS\eBaySDK\Finding\Services\FindingService;
use \DTS\eBaySDK\Finding\Types;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;
// import requests;
// from bs4 import BeautifulSoup;

# make a GET request to the URL of the page you want to scrape
// $url = 'https://www.ebay.com/itm/324975068408'


# parse the HTML content using BeautifulSoup
// soup = BeautifulSoup($response.content, 'html.parser')

# find the section containing the specifications
// spec_section = soup.find('div', {'id': 'viTabs_0_is'})

# find all rows of the specification table
// spec_rows = spec_section.find_all('div', {'class': 'ux-layout-section__row'})

# loop through each row and print the label and value of each specification
// for row in spec_rows:
//     label = row.find('span', {'class': 'ux-textspans'}).text.strip()
//     value = row.find('div', {'class': 'ux-labels-values__values-content'}).text.strip()
    // print(f'{label}: {value}')
$service = new FindingService([
    'credentials' => [
        'appId' => 'BilalSag-Scrappin-PRD-675429346-b9a29adb',
        'certId' => 'PRD-75429346b65b-43f2-4a8b-8485-4cce',
        'devId' => 'd90dd4fc-dd31-4c36-97e6-391d359c2268'
    ],
    'globalId' => 'EBAY-US',
    'apiVersion' => '1.13.0',
//    'sandbox' => true
]);
$request = new Types\FindItemsAdvancedRequest();
$request->keywords = 'phones';
$request->paginationInput = new Types\PaginationInput();
$request->paginationInput->entriesPerPage = 5;

$response = $service->findItemsAdvanced($request);

// $product_details = array();
// foreach ($response->searchResult->item as $item) {
//     $product_details[] =(string)$item->viewItemURL;
// }
// $newArray = array();
// foreach($product_details as $url) {
//     $html = file_get_html($url);

//     $spec_rows = $html->find('div[class=ux-layout-section__row]');
//     if ($spec_rows !== false) {
//         $product_data = array();
//         $product_data['label'] = 'url';
//         $product_data['value'] = $url;
//         foreach($spec_rows as $urlsss) {
//             $label = $urlsss->find('span[class=ux-textspans]', 0)->plaintext ?? '';
//             $value = $urlsss->find('div[class=ux-labels-values__values-content]', 0)->plaintext ?? '';
//             $product_data[] = array(
//                 'label' => $label,
//                 'value' => $value
//             );
//         } 
//         $newArray[] = $product_data;
//         $html->clear();
//     }
// }

// $json = json_encode($newArray);
// echo $json;
$product_details = array();
foreach ($response->searchResult->item as $item) {
    $product_details[] = array(
        'url' => (string)$item->viewItemURL,
        'image' => (string)$item->galleryURL
    );
}

$newArray = array();
foreach ($product_details as $item) {
    $url = $item['url'];
    $image = $item['image'];
    $html = file_get_html($url);

    $spec_rows = $html->find('div[class=ux-layout-section__row]');
    if ($spec_rows !== false) {
        $product_data = array();
        $product_data['source'] = 'Ebay';
        $product_data['product_url'] = $url;
        $product_data['image'] = $image;
        foreach($spec_rows as $urlsss) {
            $label = $urlsss->find('span[class=ux-textspans]', 0)->plaintext ?? '';
            $value = $urlsss->find('div[class=ux-labels-values__values-content]', 0)->plaintext ?? '';
            $product_data[$label] = isset($value) ? $value : '';
        } 
        $newArray[] = $product_data;
        $html->clear();
    }
}

$json = json_encode($newArray);
echo $json;
// $json_string = json_encode($html);
// echo $json_string;
//$request = new FindItemsByKeywordsRequest([
//    'keywords' => 'iphone',
//    'paginationInput' => [
//        'entriesPerPage' => 10,
//        'pageNumber' => 1
//    ]
//]);
//
//$response = $service->findItemsByKeywords($request);
//
//foreach ($response->searchResult->item as $item) {
//    echo $item->title . PHP_EOL;
//}
//
//require __DIR__.'/vendor/autoload.php';
//
//use GuzzleHttp\Client;
//use GuzzleHttp\Exception\GuzzleException;
//
//$client = new Client();
//
//$url = 'https://api.sandbox.ebay.com/buy/browse/v1/item_summary/search?q=phones&limit=10';
//
//$headers = [
//    'Content-Type' => 'application/json',
//    'Authorization' => 'Bearer {v^1.1#i^1#I^3#p^1#r^0#f^0#t^H4sIAAAAAAAAAOVYa2wURRzvXV+WCkjCQwmJlxVDtNm92d17rr2L15bSKy09eicUpMDe7ux16d7usTNLeyaYppKaoInGYIQYIzHUoIkiIQTRwgcTEBMxMdooKihfFD74iEZaISbO3h3lWgkUeolNvFyymZn/8zf/x8yAgaqaR4dahsbmOqqd+wfAgNPhYGtBTVVl3bxy59LKMlBE4Ng/sHygYrD8Uj0S01pG6IQoY+gIuvrTmo6E3GSIskxdMESkIkEX0xAJWBLikfY2gWOAkDENbEiGRrmiTSGK5xQP4ILQLwFJBpxEZvXrMhNGiGKDrMwBmQsGRQ8blANkHSELRnWERR2HKA5wPA3In0uwrOBlBZZneI9/I+VaB02kGjohYQAVzpkr5HjNIltvbaqIEDQxEUKFo5HmeEck2rRyTaLeXSQrXMAhjkVsocmjRkOGrnWiZsFbq0E5aiFuSRJEiHKH8xomCxUi1425C/PzUPN+6OGDfi/n87BisDRQNhtmWsS3tsOeUWVayZEKUMcqzt4OUYJGchuUcGG0hoiINrnsz1pL1FRFhWaIWtkQ2RCJxahwg6qJWlxM0XHJFDMZVafjDV206Pf6ApxPkWhWCsgyy/IFRXlpBZinaGo0dFm1QUOuNQZugMRqOBUbTxE2hKhD7zAjCrYtKqbjJzAEG+1Nze+ihXt0e19hmgDhyg1vvwMT3BibatLCcELC1IUcRCHKBkGmpi7mYrEQPv0oRPVgnBHc7r6+PqaPZwwz5eYAYN1d7W1xqQemRYrQ2rmep1dvz0CrOVckSDiRKuBshtjST2KVGKCnqLAHEHKugPtks8JTZ/81UeSze3JGlC5DvKxX8QV8ySAI+Hi+FBkSLgSp27YDJsUsnRbNXogzmihBWiJxZqWhqcoC71U4PqBAWvYFFdoTVBQ66ZV9NKtACCBMJqVg4P+UKNMN9TiUTIhLEusli/MdQd5cX2e1dkbbUlZT61Pu1cb65nRnU6yzpTma7W1NSMrq7T2r2JhvQ2i62XBT5xs1lSCTIPpLAYCd66UDocVAGMozci8uGRkYMzRVys6uDeZNOSaaONtgZck4DjWNfGbkaiSTiZamYpfMyTssFnfnd+k61X/UpW7qFbIDd3Z5ZfMjIkDMqAzpQ3auZxnJSLsNkRxC7OktOatdUwhvSuROWlkmZUGEiSUyOQdOm0klxZwhLU2ePku+YRInps9CLhmyJeG7UpTrzAxBU031YHRHOvtnAkrS0nqnzyJDUZtRiKrkqjGrApR4mndZlfN3BCbnN4N2SIwJkWGZ5HrEdNhH5oTRC3VyAMGmoWnQXMfOuPSm0xYWkxqcbTW4BLVIJbnuGJ9lJyTW5/f7vf6Af2bdQ8qdf7bMtg5S6s55Bzch9+R3mXBZ7scOOk6AQcdxp8MB/IBm68AjVeVPVJTfSyFSexgk6nLS6GdUUWFI2dNFbJmQ6YXZjKiaziqH+s2X0njRi9D+bnD/xJtQTTlbW/RABJbdWKlk5y+Zy/GABxzLeonDG8FDN1Yr2MUVC1vRqvB4svbKF1f8uzt3/nz58tmxYTB3gsjhqCwj4VvmdP3909K2zfvojr3S5Qz2DFUzu85WzWl/5epXZleWqdo8tuzhY0cXndp77Y8LT79c/UlXIr67pv6lrz1rjxz4fHT4gaGFo/vGPh0dPb7tMGhKyy+YiRUXmqvnHOweeVd5P3Vw19vV881N4UN72q89N/6ka2/3a1ufj31Wh/ru69qeOvXmn+WvXqrvTvQ6zz/+7cXHzr84r3nlpo/ObXrPWz987uTFS8+uGBwxTxt7Tjp3DdXWvV5x6EP5t8Wya+jAwWMVPyzYF+RHBkfOVA/7fn8DLBgc/pg93ci8dWzJ1sOhnVsGnkn89f2DJxYZR46f+rHlnZ2Hj7pjG/qvWN1HF/564MwH1j3fyUuvwuW/5LfxH0HdojCrEwAA}', // Replace {YOUR_ACCESS_TOKEN} with your actual access token
//    'X-EBAY-C-MARKETPLACE-ID' => 'EBAY_US'
//];
//
//try {
//    $response = $client->get($url, ['headers' => $headers]);
//
//    $body = $response->getBody();
//    $data = json_decode($body, true);
////    echo '<pre>';
////    print_r($data);
////    die();
//    foreach ($data['itemSummaries'] as $item) {
//        echo $item['title'] . PHP_EOL;
//    }
//
//} catch (GuzzleException $e) {
//    echo $e->getMessage() . PHP_EOL;
//}
//
//$app_id = 'BilalSag-Scrappin-SBX-a756826fc-1c8dd113'; // Replace with your eBay App ID
//$access_token = 'v^1.1#i^1#I^3#r^0#f^0#p^1#t^H4sIAAAAAAAAAOVYf2wTVRxf123K5kCNAkEDzQmJSO56d11/XWi13Rh0AzrWOsYI4Ovd63rselfuvWMtYlIXRVAQsqiQBQISIIR/JCZoDD8TTNREYjCgBhOMEg2SSAgCI1ES313H6CaBwZq4xKbJ5b33/fl53x/vPTZfNe6FdfPW9dfaHinflWfz5TYbV8OOq6qcNd5ePqWyjC0isO3KT89X9NgvzkYgrWSEVogymoqgI5tWVCRYkwHK0FVBA0hGggrSEAlYFGKhBfMFnmGFjK5hTdQUyhFpCFAuP4AsABKU/F5Y5xLJrHpbZlwLUB5R4hKSh/dKgAdezk3WETJgREUYqDhA8Szvolny5+McL7A+gXUxfh/fQTnaoI5kTSUkDEsFLXMFi1cvsvXepgKEoI6JECoYCTXGoqFIw5yF8dnOIlnBARxiGGADDR3VaxJ0tAHFgPdWgyxqIWaIIkSIcgYLGoYKFUK3jXkI8y2oeU/C52YlwHEAeHyctyRQNmp6GuB722HOyBKdtEgFqGIZ5+6HKEEjsRKKeGC0kIiINDjMzyIDKHJShnqAmhMOLQm1tFDBsKwAJQY66Ziog0xGVulYuJ0GXrfHx3uSIs2JPkniONeAooK0AZiHaarXVEk2QUOOhRoOQ2I1HIoNJ7iLsCFEUTWqh5LYtKiYru42ht66DnNTC7to4JRq7itMEyAc1vD+OzDIjbEuJwwMByUMX7AgClAmCBI1fNGKxYHwyaIAlcI4Izid3d3dTLeL0fROJ8+ynLN9wfyYmIJpQBFaM9cL9PL9GWjZckWEhBPJAs5liC1ZEqvEALWTCtaxhJwfwH2oWcHhs/+aKPLZOTQjSpUhHolzu3mvVwQQJoGnJBkSHAhSp2kHTIAcnQZ6F8QZBYiQFkmcGWmoy5Lgcid5ly8JacnjT9J1/mSSTrglD80lIWQhTCREv+//lCgjDfUYFHWISxLrJYvz1X6XvniW0dQamd9pNDStcTZrixvTrQ0trfMaI7mupriYbF6Vmsu1eJYERpoNd3W+XpEJMnGivxQAmLleOhDmaQhDaVTuxUQtA1s0RRZzY2uDXbrUAnScCxs5Mo5BRSGfUbkaymQipanYJXPyAYvFw/lduk71H3Wpu3qFzMAdW16Z/IgIABmZIX3IzPUcI2pppwbIIcScXmFZ7RhGeFciZ8LIMZ0GRJhYIpFz4IiZZFLMGdLSpJGzFBomcWLkLOSSIRkifihFVmdmCJpyZwqjB9KZHQ0oCUPpGjmLBIEyqhCVyVVjTAUo8bTgsiwV7giM5TeDVouMDpFm6OR6xETNI3Nc64IqOYBgXVMUqLdxoy696bSBQUKBY60Gl6AWySTXbTfH2AmJ83i9XrfP5xtd9xCt88+KsdZBSt05H+Am5Bz6LhMss35cj+0o22P7rNxmY70szc1iZ1bZX66wP0YhUnsYBFQpoWUZGSQZUvZUgA0dMl0wlwGyXl5lk8+dEW8WvQjtWsZOHnwTGmfnaooeiNhn76xUchMm1fIu1sXyHM/6WFcH+9yd1QpuYsVTJ9e2Xvhrb/+xSdsXHWyTbu12bH/6TbZ2kMhmqywj4Vv26Jm/9z3xyqu97y6/Qm+8vie4/8IPB4K/XDqV3dbw4dcH664ckvqa9sENv22qMc61T0yf/QS4tb7+x9d/dfV4zxs7Xvd+OTVb8dHM3umfLp0cK9+0cfO0q9h/Ysve44t3HzkfPzNX/7PG/sGBNd9+dy2WjxvXU291VLSdD/4UPbb57WeyR/74/ND2qTOiKx3vd53ev+DoNntd7nKu64sXb10+3GsPR9WbeOOV5Tt/nJx670D0pVT71CrHxD3Nz986fuhS+Y0TU55sutE3fssOu7Z0efXPud4Lq37dura6+fT0Za/N2FB/af2qaWu21k54h11ff7Yv/70WOVZ9+NrpUxd3fvyNFP69GvbjaN+c6ycL2/gPX0mmAKsTAAA='; // Replace with your eBay Auth Token
//
//// Set the API endpoint and headers
//$endpoint = 'https://api.sandbox.ebay.com/buy/browse/v1/item_summary/search?q=drone&limit=3';
//$headers = array(
//    'Authorization: Bearer ' . $access_token,
//    'Content-Type: application/json',
//    'X-EBAY-C-MARKETPLACE-ID: EBAY_US'
//);
//
//// Set the query parameters for the API call
////$params = array(
////    'q' => 'mobile phones', // search query
////    'category_ids' => array('9355'), // category ID(s)
////    'limit' => 50, // number of results per page
////    'offset' => 0 // starting index for results
////);
//
//// Build the URL with the query parameters
////$url = $endpoint . '?' . http_build_query($params);
//
//// Make the API call
//$ch = curl_init();
//curl_setopt($ch, CURLOPT_URL, $endpoint);
//curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
//curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//$response = curl_exec($ch);
//curl_close($ch);
//
//// Parse the JSON response
//$json_response = json_decode($response, true);
//
//// Output the results
//if (isset($json_response['itemSummaries'])) {
//    foreach ($json_response['itemSummaries'] as $item) {
//        echo $item['title'] . "\n";
//        echo $item['price']['value'] . ' ' . $item['price']['currency'] . "\n";
//        echo $item['itemHref'] . "\n\n";
//    }
//} else {
//    echo 'No results found.';
//}
